"""
ColorHighligter.

A Sublime Text plugin for highlighting CSS colors in code.
"""
